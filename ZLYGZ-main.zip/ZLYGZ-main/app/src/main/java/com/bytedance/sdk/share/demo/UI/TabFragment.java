package com.bytedance.sdk.share.demo.UI;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bytedance.sdk.share.demo.R;

public class TabFragment extends Fragment {
    public static TabFragment newInstance(String label){
        Bundle args = new Bundle();
        args.putString("label",label);
        TabFragment tabFragment=new TabFragment();
        tabFragment.setArguments(args);
        return tabFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        return inflater.inflate(R.layout.fragment_tab,container,false);
    }

    @Override
    public void onStart(){
        super.onStart();
        String label=getArguments().getString("label");
        TextView textView=getView().findViewById(R.id.tab_content);
        textView.setText(label);
        textView.setBackgroundColor(Color.rgb((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255)));
    }
}