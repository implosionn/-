package com.bytedance.sdk.share.demo.UI;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bytedance.sdk.share.demo.R;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class ListUiFragment extends Fragment {

    private ArrayList<Fragment> list = new ArrayList<>();
    //    private ArrayList<String> title = new ArrayList<>();
    private MovieFragment movieFragment;
    private TvFragment tvFragment;
    private VarietyFragment varietyFragment;
    ArrayList fragmentList=new ArrayList<Fragment>();

    private View contextView;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    private String[] tabs={"电影","电视剧","综艺"};
    private List<TabFragment> tabFragmentList=new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contextView = inflater.inflate(R.layout.fragment_list_ui, container,false);

        if(movieFragment==null) {
            movieFragment = new MovieFragment();
        }
        if(tvFragment==null) {
            tvFragment = new TvFragment();
        }
        if(varietyFragment==null) {
            varietyFragment = new VarietyFragment();
        }

        fragmentList.add(movieFragment);
        fragmentList.add(tvFragment);
        fragmentList.add(varietyFragment);

       /* list.add(movieFragment);
        list.add(tvFragment);
        list.add(varietyFragment);*/

        //初始化viewpager
        viewPager = contextView.findViewById(R.id.list_vp);
        //初始化tablayout
        tabLayout = contextView.findViewById(R.id.list_tab);

        viewPager.setOffscreenPageLimit(3);
        //     viewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager(),FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        //适配器
        //  LFAdapter adapter = new LFAdapter(getChildFragmentManager(), list, title);
        //缓存数量
      /*  viewPager.setOffscreenPageLimit(2);
        viewPager.setAdapter(adapter);*/
        return contextView;
    }

    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState){
        super.onViewCreated(view,savedInstanceState);
        MPagerAdapter mPagerAdapter=new MPagerAdapter(getChildFragmentManager());
        //    initList();
        //绑定
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter(mPagerAdapter);
    }

    class MPagerAdapter extends FragmentPagerAdapter {

        public MPagerAdapter(FragmentManager fragmentManager){
            super(fragmentManager);
        }

        @Override
        public Fragment getItem(int position){
            return (Fragment)fragmentList.get(position);
        }

        @Override
        public int getCount(){
            return fragmentList.size();
        }

        @Override
        public Object instantiateItem(ViewGroup container,int position){
            return super.instantiateItem(container,position);
        }

        @Override
        public CharSequence getPageTitle(int position){
            return tabs[position];
        }
    }
}