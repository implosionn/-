package com.bytedance.sdk.share.demo.UI;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.bytedance.sdk.share.demo.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VarietyFragment extends Fragment {

    private ListView listView;
    private List<Map<String, Object>> mapList=new ArrayList<Map<String,Object>>();
    private SimpleAdapter simpleAdapter;
    private int[] imags = {
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5
    };

    private ImageView imageView;
    private TextView textView;
    private LinearLayout linearLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_variety, null);
        //初始化列表信息
        listView=(ListView) view.findViewById(R.id.list_variety);

        for (int i = 0; i < 50; i++) {
            Map<String ,Object> map=new HashMap<>();
            map.put("img",imags[(i+2 )% imags.length]);
            map.put("title","标题"+i);
            map.put("content","内容"+i);
            mapList.add(map);
        }

        SimpleAdapter simpleAdapter=new SimpleAdapter(getActivity(),
                mapList,
                R.layout.simple_item_layout,
                new String[]{"img","title","content"},
                new int[]{R.id.i_image,R.id.t_title,R.id.t_content});

        listView.setAdapter(simpleAdapter);
        return view;
    }
}