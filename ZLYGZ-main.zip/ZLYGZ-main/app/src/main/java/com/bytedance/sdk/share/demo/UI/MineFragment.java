package com.bytedance.sdk.share.demo.UI;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bytedance.sdk.share.demo.R;
import com.bytedance.sdk.share.demo.douyinapi.DouYinEntryActivity;
import com.google.android.material.tabs.TabLayout;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MineFragment extends Fragment {

    private ArrayList<Fragment> list = new ArrayList<>();
    //    private ArrayList<String> title = new ArrayList<>();
    private UserMineFragment userMineFragment;
    private UserLikeFragment userLikeFragment;
    private UserCollectFragment userCollectFragment;
    ArrayList fragmentList=new ArrayList<Fragment>();

    private View contextView;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    private String[] tabs={"发布","收藏","喜欢"};
    private List<TabFragment> tabFragmentList=new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.fragment_mine,null);

        if(userMineFragment==null){
            userMineFragment=new UserMineFragment();
        }
        if(userLikeFragment==null){
            userLikeFragment=new UserLikeFragment();
        }
        if(userCollectFragment==null){
            userCollectFragment=new UserCollectFragment();
        }

        fragmentList.add(userCollectFragment);
        fragmentList.add(userLikeFragment);
        fragmentList.add(userMineFragment);

        viewPager=view.findViewById(R.id.user_vp);
        tabLayout=view.findViewById(R.id.user_tab);
        TextView username = view.findViewById(R.id.user_name);
        TextView title =view.findViewById(R.id.t_title);
        //ImageView touxiang =view.findViewById(R.id.user_img2);
        username.setText(DouYinEntryActivity.nickname);
        return view;

    }

    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState){
        super.onViewCreated(view,savedInstanceState);
        MineFragment.MPagerAdapter mPagerAdapter=new MPagerAdapter(getChildFragmentManager());
        //    initList();
        //绑定
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter(mPagerAdapter);

    }

    class MPagerAdapter extends FragmentPagerAdapter {

        public MPagerAdapter(FragmentManager fragmentManager){
            super(fragmentManager);
        }

        @Override
        public Fragment getItem(int position){
            return (Fragment)fragmentList.get(position);
        }

        @Override
        public int getCount(){
            return fragmentList.size();
        }

        @Override
        public Object instantiateItem(ViewGroup container,int position){
            return super.instantiateItem(container,position);
        }

        @Override
        public CharSequence getPageTitle(int position){
            return tabs[position];
        }
    }

}