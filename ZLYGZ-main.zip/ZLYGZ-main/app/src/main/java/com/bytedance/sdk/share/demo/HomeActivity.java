package com.bytedance.sdk.share.demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bytedance.sdk.open.aweme.authorize.model.Authorization;
import com.bytedance.sdk.open.douyin.DouYinOpenApiFactory;
import com.bytedance.sdk.open.douyin.DouYinOpenConfig;
import com.bytedance.sdk.open.douyin.api.DouYinOpenApi;
import com.bytedance.sdk.share.demo.R;
import com.bytedance.sdk.share.demo.UI.HomeFragment;
import com.bytedance.sdk.share.demo.UI.ListUiFragment;
import com.bytedance.sdk.share.demo.UI.MineFragment;
import com.bytedance.sdk.share.demo.douyinapi.DouYinEntryActivity;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = "HOMEActivity";
    private ImageView ihome, ilist, imine;
    private TextView thome, tlist, tmine;
    private LinearLayout llhome, lllist, llmine;
    private Fragment fhome, flist, fmine;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private Fragment fragment;
    private String mScope = "trial.whitelist,user_info,following.list,fans.list,video.list,video.data";
    private String mOptionalScope1 = "friend_relation";
    private String mOptionalScope2 = "message";
    private String access_token = DouYinEntryActivity.access_token;
    DouYinOpenApi douYinOpenApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initFrag();
    }
    private void initFrag() {
        llhome = findViewById(R.id.ll_home);
        lllist = findViewById(R.id.ll_list);
        llmine = findViewById(R.id.ll_mine);
        ihome = findViewById(R.id.i_home);
        ilist = findViewById(R.id.i_list);
        imine = findViewById(R.id.i_mine);
        thome = findViewById(R.id.t_home);
        tlist = findViewById(R.id.t_list);
        tmine = findViewById(R.id.t_mine);

        llhome.setOnClickListener(listener);
        lllist.setOnClickListener(listener);
        llmine.setOnClickListener(listener);

        //默认首页
        setTabSelect(0);
    }
    //点击切换页面
    View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            resetMenu();
            switch (v.getId()) {
                case R.id.ll_home:
                    setTabSelect(0);
                    break;
                case R.id.ll_list:
                    setTabSelect(1);
                    break;
                case R.id.ll_mine:
                    setTabSelect(2);
                    break;
            }
        }
    };

    private void resetMenu() {
        ihome.setSelected(false);
        thome.setTextColor(getResources().getColor(R.color.gray));
        ilist.setSelected(false);
        tlist.setTextColor(getResources().getColor(R.color.gray));
        imine.setSelected(false);
        tmine.setTextColor(getResources().getColor(R.color.gray));
    }

    //页面切换
    private void setTabSelect(int index) {
        if (fragmentManager == null) {
            fragmentManager = getSupportFragmentManager();
        }
        fragmentTransaction = fragmentManager.beginTransaction();
        hideAllFragment(fragmentTransaction);
        switch (index) {
            case 0:
                if (fhome == null) {
                    fhome = new HomeFragment();
                    fragmentTransaction.add(R.id.home_fragment, fhome);
                } else {
                    fragmentTransaction.show(fhome);
                }
                ihome.setSelected(true);
                thome.setTextColor(getResources().getColor(R.color.selected));
                break;
            case 1:
                if (flist == null) {
                    flist = new ListUiFragment();
                    fragmentTransaction.add(R.id.home_fragment, flist);
                }
                fragmentTransaction.show(flist);
                ilist.setSelected(true);
                tlist.setTextColor(getResources().getColor(R.color.selected));
                /*ilist.setSelected(true);
                tlist.setTextColor(getResources().getColor(R.color.selected));
                Intent intent=new Intent(this,TabActivity.class);
                startActivity(intent);*/
                break;
            case 2:
                if (fmine == null) {
                    fmine = new MineFragment();
                    fragmentTransaction.add(R.id.home_fragment, fmine);
                }
                fragmentTransaction.show(fmine);
                imine.setSelected(true);
                tmine.setTextColor(getResources().getColor(R.color.selected));
                break;
            default:
                break;
        }
        fragmentTransaction.commit();
    }

    //避免页面覆盖
    private void hideAllFragment(FragmentTransaction fragmentTransaction) {
        if (fhome != null) {
            fragmentTransaction.hide(fhome);
        }
        if (flist != null) {
            fragmentTransaction.hide(flist);
        }
        if (fmine != null) {
            fragmentTransaction.hide(fmine);
        }
    }
}